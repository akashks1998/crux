// basic array and loop 

int main()
{
     int marks[10], i, n, sum = 0, average;
     for(i=0; i<n; i++ ){
          sum += marks[++i];
     }
     average = sum/n;

     int *a,*b;
     a = b + 2;
     return 0;
}