 class x{
    int a;
    int f(int b);
  };
  class x:: int f(int y){
    	if(this->a > y){
       	return 0;
      }else{
      	return 1;
      }
  }