int fact(int n){
  if(n>0){
    return n*fact(n-1);
  }
  return 1;
}
int main(){
  int size;
  int a=fact(20);
  return 0;
}