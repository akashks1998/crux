// array of class and its assignment to and use of array element
class hi{
    int a, b;
};

int main(){
    class hi list[5];
    class hi H;
    list[3] = list[2];
    int *i,*j;
    *i = *j;

    int *a[3][5][8], *b;
    a[2][2][6] =  a[2][2][6] + 1;
    return 0;

}