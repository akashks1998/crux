#include<std.cpp>
int a[1000];
int f(int j){
     return f(j);
}
int main()
{
     int marks[10], i, n, sum = 0, average;
     for(i=0; i<n; i++ ){
          break;
          sum += marks[++i];
     }
     switch(n){
          case 1:
          i=0;break;
          case 2:
          i=1;break;
          default:
          i=0;
     }
     average = sum/n;
     int * t=average;
     delete t;
     int x=f(i);
     int *a,*b;
     a = b + 2;
     return 0;
}
