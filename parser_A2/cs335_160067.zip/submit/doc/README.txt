Command to run :
1. go to <top-dir>/src
2. run ./cmd --help to get info how to use the file

Currently the parser can parse a subset of C++.
We have named this language Crust.
Most of the features are covered in the testcases.