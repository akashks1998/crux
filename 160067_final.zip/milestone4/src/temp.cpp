int f(int a) {

   return a+1;

}

int main() {

   int f, g;

   g = f(4);

   return 0;

}