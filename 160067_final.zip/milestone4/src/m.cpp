int main() 
{ 
    int n = 12;
    int *arb = new (int)[n];
    for(int i=0; i< n; i++){
        arb[i] = 50 * i;
    }
    
    int *a = arb;
    for(int i=0; i<n; i++){
        print_int(a[i]);
    }
    return 0; 
}
