int main()
{
    int x=10;
    int y;
     
    y=-10;

    print_int(x);
    print_int(y);
    y = x-y;
    print_int(y);
 
    return 0;
}