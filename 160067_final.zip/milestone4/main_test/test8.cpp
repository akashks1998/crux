int main()

{
 int a[7];
 print_int(a[0]);
 a[1] = 36542;
 print_int(a[1]);
 return 0;
}