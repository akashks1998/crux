int main()

{

 int a;

 a= 5;

 a++;

 print_int(a);
 return 0;

}