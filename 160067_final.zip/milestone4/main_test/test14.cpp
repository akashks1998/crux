int returnChar () {

   return 0;

}




int main () {

   int a;

   int b;

   int c[3];




   c[ returnChar() ] = 1;


    return 0;

}
