int main()

{

 int i=0;

 int j=0;

 j = i+ j++;

print_int(j);
return 0;
}