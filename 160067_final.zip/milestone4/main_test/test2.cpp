struct hello {

       int a;

       float b;

       int d;

};

 

int main() {

       int b;

       int a;

       struct hello k;  

 

       a = k.d;

 

       return 0;

}