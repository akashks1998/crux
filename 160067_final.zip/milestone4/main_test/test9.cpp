int f (int b ) {     

   int a;

   a=5;

   return a;

}

 

int main () {

   int a,b;

   a = 9;

   b = f(a);

   print_int(a);
   print_int(b);
    return 0;
}

