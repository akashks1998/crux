int j;
class e{
     int x;
     int y;
};
int main()
{
     j=5;
     auto k=j*5;
     auto i=k;
     class e x;
     auto z=x;
     auto f=(1.09+1);
     for (auto z=0;z<100;z++){
          print_int(z);
     }
     print_float(f);
     char m=10;
     print_char(10);
     auto t=new(int)[5];
     print_int(i);
     return 0;
}
