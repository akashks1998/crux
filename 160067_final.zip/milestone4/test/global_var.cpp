class b{
  int a;
};
int a[100];
int x;
class b d;
int main(){
  a[1]=2;
  d.a = 100;
  class b *f;
  f = &d;
  f->a = 200;
  print_int(d.a);

  return 0;
}