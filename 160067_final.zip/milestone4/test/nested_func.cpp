int hi(int i){
    int x = 3;
    int hi(int i){
        return 2 * i;
    }
    int a = hi(4);
    print_char('c');
    print_int(a);
    return i;
}

int main(){
    int a = 0;
    a = hi(1);
    print_int(a);
    return 0;
}